from flask import Flask,render_template, request, redirect
import os
import pandas as pd

os.chdir('C:\\AIML\\capstone\\data')
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods =["GET", "POST"])
def upload():
    if request.method == 'POST':
        if request.files:
            app.config['FILE_UPLOADS'] = "C:\\AIML\\capstone\\data"
            uploaded_file = request.files['filename']
            filepath = os.path.join(app.config['FILE_UPLOADS'], uploaded_file.filename)
            uploaded_file.save(uploaded_file)
    # Put all form entries values in a list 
    #features = request.form.values()
    # Convert features to array
    #array_features = [np.array(features)]
    # Predict features
    #prediction = model.predict(array_features)
    #output = features
    #return {'features':str(features)}
    # Check the output values and retrieve the result with html tag based on the value
 #if output == 1:
    #return render_template('index.html', 
 #result = 'Value read successfully')
 #else:
    #return render_template('index.html', 
    return render_template('index.html',result = filepath)
 #)